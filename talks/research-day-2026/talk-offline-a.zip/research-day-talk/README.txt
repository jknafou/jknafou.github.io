THE TALK, OFFLINE
=================

1. Unzip BOTH talk-offline-a.zip and talk-offline-b.zip in the same folder
   (double-click each). You get research-day-talk/ and research-day-talk-part-b/.
2. Mac: double-click research-day-talk/start.command
   (the first time: right-click it > Open, as it is not from the App Store).
   Windows: double-click research-day-talk\start.bat
   It merges part b in, serves the folder on http://localhost:8765/ and opens the browser.
3. Or by hand, in a terminal, in research-day-talk/:
       python3 -m http.server 8765
   then open http://localhost:8765/   (merge research-day-talk-part-b/ into it first).

Keys: arrows travel, F full screen, O the offline panel.
