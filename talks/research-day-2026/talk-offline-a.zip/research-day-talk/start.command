#!/bin/bash
# the talk, offline: merge part b, serve this folder, open the browser
cd "$(dirname "$0")"
B="../research-day-talk-part-b"
[ -d "$B" ] && ditto "$B" .
( sleep 1; open "http://localhost:8765/" ) &
exec python3 -m http.server 8765
