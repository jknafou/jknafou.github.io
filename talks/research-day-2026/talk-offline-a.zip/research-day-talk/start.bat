@echo off
rem the talk, offline: merge part b, serve this folder, open the browser
cd /d "%~dp0"
if exist "..\research-day-talk-part-b" xcopy /E /Y /Q "..\research-day-talk-part-b\*" ".\" >nul
start "" "http://localhost:8765/"
python -m http.server 8765 || py -m http.server 8765
