THE DECK, OFFLINE
=================
1. Unzip every deck-offline*.zip into the same folder (double-click each).
2. Mac: double-click ntcir19-r2c2-epfl/start.command (the first time: right-click > Open).
   Windows: double-click ntcir19-r2c2-epfl\start.bat
   It serves the folder on http://localhost:8765/ and opens the browser.
3. Or, in a terminal, in ntcir19-r2c2-epfl/:  python3 -m http.server 8765   then open http://localhost:8765/
Keys: arrows, F full screen, S timer, H help.
